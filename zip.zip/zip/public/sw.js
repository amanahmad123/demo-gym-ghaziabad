const CACHE = 'demo-gym-shell-v3';
const BASE = new URL('./', self.registration.scope);
const SHELL = [new URL('./', BASE).href, new URL('index.html', BASE).href, new URL('manifest.webmanifest', BASE).href, new URL('gym-icon.svg', BASE).href];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL))));
self.addEventListener('activate', event => event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))));
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET' || new URL(event.request.url).origin !== self.location.origin) return;
  event.respondWith(caches.match(event.request).then(cached => cached || fetch(event.request).then(response => {
    if (response.ok) { const copy = response.clone(); caches.open(CACHE).then(cache => cache.put(event.request, copy)); }
    return response;
  }).catch(() => caches.match(new URL('index.html', BASE).href))));
});
